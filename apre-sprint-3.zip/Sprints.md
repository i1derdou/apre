#TODO List

## Sprint 1 Minor and Major Development Tasks
- [x] Minor: Change the button text to "Get Data" in the SalesByRegionTabularComponent.
- [ ] Major: Create an API to fetch sales data by region and product and build an Angular component to display sales by region and product using ChartComponent or TableComponent with 3 unit tests each.

## Sprint 2
- [ ] Minor: m-053 Add a tooltip to the edit icon in the UsersComponent.
- [ ] Major: M-089 Create an API to fetch agent performance data by customer feedback and build an Angular component to display agent performance by customer feedback using ChartComponent or TableComponent with 3 unit tests each.